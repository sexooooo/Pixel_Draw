# pixel_drawn
 drawing pixels in the graphical interface of a Windows Form project created in Visual Studio with PL C #.
